The files in this folder contain the data used for training the models.

Each file contains the data in JSON format. The structure is a mapping from the SMILE string of the molecule to a list of descriptor values.

Furthermore this folder contains the response matrix from the [DoOR dataset](http://neuro.uni-konstanz.de/DoOR/default.html) in CSV and JSON format.